from django.apps import AppConfig


class MywebsiteConfig(AppConfig):
    name = 'MyWebsite'
